import requests
from bs4 import BeautifulSoup
import telegram
import schedule
import time
import os

BOT_TOKEN = os.getenv("BOT_TOKEN")
CHAT_ID = os.getenv("CHAT_ID")

bot = telegram.Bot(token=BOT_TOKEN)

def fetch_idealista():
    url = "https://www.idealista.com/en/venta-viviendas/ibiza-baleares/con-precio-hasta_300000,metros-cuadrados-mas-de_40/"
    r = requests.get(url, headers={"User-Agent": "Mozilla/5.0"})
    soup = BeautifulSoup(r.text, "html.parser")
    items = soup.find_all("div", class_="item-info-container")
    results = []
    for item in items[:5]:
        title = item.find("a", class_="item-link").get_text(strip=True)
        link = "https://www.idealista.com" + item.find("a", class_="item-link")["href"]
        price = item.find("span", class_="item-price").get_text(strip=True)
        results.append(f"{title} - {price}\n{link}")
    return results

def send_report():
    flats = fetch_idealista()
    if not flats:
        bot.send_message(chat_id=CHAT_ID, text="Нет новых предложений")
    else:
        text = "Новые предложения на Idealista:\n\n" + "\n\n".join(flats)
        bot.send_message(chat_id=CHAT_ID, text=text)

schedule.every().day.at("07:00").do(send_report)
schedule.every().day.at("19:00").do(send_report)

bot.send_message(chat_id=CHAT_ID, text="Бот запущен и будет присылать отчёты в 07:00 и 19:00")

while True:
    schedule.run_pending()
    time.sleep(30)
